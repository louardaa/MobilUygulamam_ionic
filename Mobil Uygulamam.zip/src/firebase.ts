import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import 'firebase/firestore';


const firebaseConfig = {
  apiKey: "AIzaSyCiSFl2YdFqEQlmhpW6_LbIVYuvCLLVZmM",
  authDomain: "mobiluygulamam-d2a6d.firebaseapp.com",
  projectId: "mobiluygulamam-d2a6d",
  storageBucket: "mobiluygulamam-d2a6d.appspot.com",
  messagingSenderId: "293918081654",
  appId: "1:293918081654:web:364512bb8f581b7cfc9557",
  measurementId: "G-Z775T8LZ7R"
};
firebase.initializeApp(firebaseConfig);

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

firebase.initializeApp(firebaseConfig);

const firebaseAuth = firebase.auth();
const app = firebase.initializeApp(firebaseConfig)
const firestore = firebase.firestore();

export const auth = app.auth()
export { firebaseAuth };
export default firestore;




