import {
    IonContent,
    IonHeader,
    IonPage,
    IonTitle,
    IonToolbar,
    IonButton,
    IonInput,
    IonItem,
    IonToast,
    IonList,
    IonLabel,
    IonText,
    IonSpinner,
  } from '@ionic/react';
  import React, { useState } from 'react';
  import './Tab1.css';
  import { auth } from '../firebase';
  import { Redirect, useHistory } from 'react-router';
  import { useAuth } from '../auth';
  
  const SifreMiSifirla: React.FC = () => {
    const { loggedIn } = useAuth();
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState({ loading: false, error: false, success: false });
    const history = useHistory();
  
    const handleForgotPassword = async () => {
      try {
        if (!email) {
          setStatus({ loading: false, error: true, success: false });
          return;
        }
  
        setStatus({ loading: true, error: false, success: false });
  
        // Check if the email is registered in Firebase
        const isEmailRegistered = await checkEmailIsRegistered(email);
  
        if (isEmailRegistered) {
          // Send password reset email
          await auth.sendPasswordResetEmail(email);
  
          // Show success message
          setStatus({ loading: false, error: false, success: true });
        } else {
          // Email is not registered
          setStatus({ loading: false, error: true, success: false });
        }
      } catch (error) {
        setStatus({ loading: false, error: true, success: false });
        console.log('error:', error);
      }
    };
  
    // Helper function to check if the email is registered in Firebase
    const checkEmailIsRegistered = async (email: string) => {
      try {
        const user = await auth.fetchSignInMethodsForEmail(email);
        return user.length > 0; // If the user array has length > 0, email is registered
      } catch (error) {
        console.log('Error checking email:', error);
        return false; // Assume email is not registered on error
      }
    };
  
    if (loggedIn) {
      return <Redirect to="/my/entries" />;
    }
  
    return (
      <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Şifremi Sıfırla</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          <div className="sifremisifirla-container">
            <IonList className="ion-padding">
              <IonItem>
                <IonLabel position="stacked">E-posta</IonLabel>
                <IonInput
                  type="email"
                  value={email}
                  onIonChange={(event) => setEmail(event.detail.value!)}
                />
              </IonItem>
            </IonList>
            {status.error && (
              <IonText color="danger">E-posta adresi kayıtlı değil.</IonText>
            )}
            {status.success && (
              <IonText color="success">Şifre sıfırlama e-postası gönderildi.</IonText>
            )}
            <IonButton className="sifremisifirla-button" onClick={handleForgotPassword}>
              Şifremi Sıfırla
            </IonButton>
            {status.loading && <IonSpinner />}
          </div>
        </IonContent>
      </IonPage>
    );
  };
  
  export default SifreMiSifirla;
  