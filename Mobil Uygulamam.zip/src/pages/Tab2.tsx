import { IonApp, IonContent, IonHeader, IonInput, IonPage, IonTitle, IonToolbar, IonButton, IonText, IonToast, IonIcon } from '@ionic/react';
import { useState, useEffect } from 'react';
import { auth } from '../firebase';
import { Redirect, useHistory } from 'react-router';
import { cart, home, personOutline } from 'ionicons/icons';

const Tab2: React.FC = () => {
  const [name, setName] = useState('');
  const [emailVerified, setEmailVerified] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const history = useHistory();

  useEffect(() => {
    const checkEmailVerification = () => {
      const user = auth.currentUser;
      if (user && user.emailVerified) {
        setEmailVerified(true);
        setShowMessage(true);
      }
    };

    const checkPhoneVerification = () => {
      const user = auth.currentUser;
      // Burada telefon doğrulama durumu kontrol edilir, örnek olarak phoneVerified değeri true/false olarak set edilir
      if (user && phoneVerified) {
        setPhoneVerified(true);
        setShowMessage(true);
      }
    };

    checkEmailVerification();
    checkPhoneVerification();
  }, [phoneVerified]);

  const handleVerifyEmail = () => {
    const user = auth.currentUser;
    if (user) {
      user.sendEmailVerification()
        .then(() => {
          setShowToast(true);
          saveNameToDatabase();
        })
        .catch((error) => {
          // Hata durumunda yapılacak işlemler
          console.log('E-posta doğrulama hatası:', error);
        });
    }
  };

  const handleVerifyPhone = () => {
    // Telefon doğrulama işlemleri burada gerçekleştirilir
    // Örnek olarak telefon doğrulandığında phoneVerified değeri true olarak set edilir
    setPhoneVerified(true);
    saveNameToDatabase();
    history.push('/dogrulama'); // Doğrulama sayfasına yönlendirme
  };

  const saveNameToDatabase = () => {
    // İsmi veritabanına kaydetmek için gerekli işlemler yapılır (Firebase Firestore gibi)
    console.log('İsim kaydedildi:', name);
  };

  const handleEditProfile = () => {
    // Profil düzenleme işlemleri burada yapılır
    history.push('/profil'); // Profil düzenleme sayfasına yönlendirme
  };
  const handleEditAnasayfa = () => {
    // Profil düzenleme işlemleri burada yapılır
    history.push('/tab1'); // Profil düzenleme sayfasına yönlendirme
  };
  const handleEditSepet = () => {
    // Profil düzenleme işlemleri burada yapılır
    history.push('/sepet'); // Profil düzenleme sayfasına yönlendirme
  };

  if (emailVerified && phoneVerified) {
    return <Redirect to="/dogrulama" />;
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Hoş Geldiniz</IonTitle>
          <IonButton slot="end" onClick={handleEditAnasayfa}>
            <IonIcon icon={home} />
          </IonButton>
          <IonButton slot="end" onClick={handleEditSepet}>
            <IonIcon icon={cart} />
          </IonButton>
          <IonButton slot="end" onClick={handleEditProfile}>
            <IonIcon icon={personOutline} />
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent className='ion-padding'>
        <IonInput placeholder='İsminiz' value={name} onIonChange={(event) => setName(event.detail.value!)} />
        {!emailVerified && (
          <IonButton expand="block" onClick={handleVerifyEmail}>
            Maili Doğrula
          </IonButton>
        )}
        {!phoneVerified && (
          <IonButton expand="block" onClick={handleVerifyPhone}>
            Telefonu Doğrula
          </IonButton>
        )}
        {showMessage && (
          <>
            <p>
              Merhaba: <b>{name} </b>
            </p>
            {emailVerified ? (
              <IonText color="success">Mail doğrulandı</IonText>
            ) : (
              <IonText color="warning">Mail doğrulanmadı</IonText>
            )}
            {phoneVerified ? (
              <IonText color="success">Telefon doğrulandı</IonText>
            ) : (
              <IonText color="warning">Telefon doğrulanmadı</IonText>
            )}
          </>
        )}
      </IonContent>
      <IonToast
        isOpen={showToast}
        message="Doğrulama maili e-posta adresinize gönderildi. Lütfen kontrol edin ve tekrar giriş yapın."
        duration={3000}
        position="top"
        onDidDismiss={() => setShowToast(false)}
      />
    </IonPage>
  );
};

export default Tab2;
