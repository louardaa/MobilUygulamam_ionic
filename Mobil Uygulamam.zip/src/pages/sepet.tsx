import React, { useEffect, useState } from 'react';
import { IonHeader, IonToolbar, IonContent } from '@ionic/react';
import { Link, useHistory } from 'react-router-dom';
import firebase from 'firebase/compat/app';
import { Siparis } from './types';

import 'firebase/compat/firestore';

export interface SepetItem {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    description: string;
  };
  variant: {
    color: string;
    size: string;
  };
  quantity: number;
}


const Sepet: React.FC<{ SepetItems: SepetItem[] }> = ({ SepetItems }) => {
  // Rest of the Sepet component code
  const history = useHistory();
  const [siparis, setSiparis] = useState<Siparis[]>([]);
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [sepetItems, setSepetItems] = useState<SepetItem[]>([]);

  useEffect(() => {
    const fetchSiparis = async () => {
      try {
        const db = firebase.firestore();
        const snapshot = await db.collection('siparis').get();
        const fetchedSiparis = snapshot.docs.map((doc) => doc.data() as Siparis);
        setSiparis(fetchedSiparis);
        console.log('siparis', fetchedSiparis);
      } catch (error) {
        console.error('Veri çekme hatası:', error);
      }
    };

    // Call the fetchSiparis function to fetch the data.
    fetchSiparis();
  }, []);


  const handleAddToSepet = (newItem: SepetItem) => {
    setSepetItems((prevItems) => [...prevItems, newItem]);
  };


  


  const handleCheckout = async () => {
    try {
      const db = firebase.firestore();

      // Sipariş ID'sini oluşturun
      const orderId = generateOrderId();

      // Sipariş verilerini hazırlayın
      const orderData = {
        orderId,
        items: SepetItems,
        totalPrice,
        createdAt: firebase.firestore.Timestamp.now(),
      };

      // Siparişi Firebase'e kaydedin
      await db.collection('siparis').doc(orderId).set(orderData);

      // Add new item to SepetItems state in the parent component
      addToSepet({
        product: {
          id: 'product-id',
          name: 'Product Name',
          price: 100,
          image: 'product-image-url',
          description: 'Product description',
        },
        variant: {
          color: 'red',
          size: 'large',
        },
        quantity: 1,
      });

      // Siparişin başarıyla kaydedildiğini bildirin
      console.log('Sipariş başarıyla kaydedildi.');

      // Yönlendirmeyi yapın (isteğe bağlı olarak)
      history.push('/siparisler');
    } catch (error) {
      console.error('Sipariş kaydetme hatası:', error);
    }
  };

  const generateOrderId = () => {
    return Math.random().toString(36).substr(2, 9);
  };

  // Sepet içeriğini ve toplam fiyatı burada hesaplayın (daha önceki kodlardan alıyorum)
  // ... <h3 className="product-Name">{siparis.productName}</h3>

  return (
    <IonHeader>
      <IonToolbar>
      <IonContent>
      {siparis.length > 0 ? (
  siparis.map((siparisItem, index) => (
    <Link to={`/siparis/${siparisItem.id}`} key={index}>
      <div className="urun-card">
        {/* Erişim öncesinde varlık kontrolü yapın */}
        {siparisItem.product && (
          <h3 className="product-Name">{siparisItem.product.name}</h3>
        )}
        {<h3 className="product-orderId">{siparisItem.orderId}</h3>
<h3 className="product-productPrice">{siparisItem.productPrice}</h3>
<h3 className="product-quantity">{siparisItem.quantity}</h3>
<h3 className="product-color">{siparisItem.variant.color}</h3>
<h3 className="product-size">{siparisItem.variant.size}</h3>
<p className="product-Name">{siparisItem.product.name}</p>
        {/* ... */}
      </div>
    </Link>
  ))
) : (
  <p>Henüz sipariş bulunmamaktadır.</p>
)}

</IonContent>

      </IonToolbar>
    </IonHeader>
  );
};


export default Sepet;
function addToSepet(arg0: { product: { id: string; name: string; price: number; image: string; description: string; }; variant: { color: string; size: string; }; quantity: number; }) {
  throw new Error('Function not implemented.');
}

