import React, { useEffect, useState } from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import { useParams } from 'react-router-dom';
import { Product, Users } from './types';

const ProductDetail: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [addedByUser, setAddedByUser] = useState<Users | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const db = firebase.firestore();
        const productDoc = await db.collection("products").doc(productId).get();
        const fetchedProduct = productDoc.data() as Product;
        setProduct(fetchedProduct);

        // Fetch the user who added the product
        const userDoc = await db.collection("users").doc(fetchedProduct.addedBy).get();
        const addedByUserData = userDoc.data() as Users;
        setAddedByUser(addedByUserData);
      } catch (error) {
        console.error("Ürün verisini çekme hatası:", error);
      }
    };

    fetchProduct();
  }, [productId]);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Ürün Detayı</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {product && addedByUser ? (
          <div className="urun-detail">
            <h3 className="product-title">{product.name}</h3>
            <img src={product.image} alt="Ürün" />
            <p className="product-desc">{product.description}</p>
            <p className="product-price">Ürün Fiyatı: <span className="product-price-small">{product.price}</span></p>
            <p className="product-added-by">Ekleyen Kullanıcı: {addedByUser.name}</p>
            <p className="product-added-by">Kullanıcının E-Posta Adresi: {addedByUser.email}</p>
            <p className="product-added-by">Kullanıcının Telefonu: {addedByUser.phone}</p>
            <p className="product-added-by">Kullanıcının Telefonu: {addedByUser.phoneNumber}</p>
            <div className="product-buy"><button className="btn">Satın Al</button></div>
          </div>
        ) : (
          <p>Ürün yükleniyor...</p>
        )}
      </IonContent>
    </IonPage>
  );
};

export default ProductDetail;
