import { IonApp, IonContent, IonHeader, IonInput, IonPage, IonTitle, IonToolbar, IonButton, IonText } from '@ionic/react';
import { useState } from 'react';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import { auth } from '../firebase';

const Dogrulama: React.FC = () => {
  const [phone, setPhone] = useState('');
  const [verificationId, setVerificationId] = useState('');
  const [code, setCode] = useState('');
  const [status, setStatus] = useState({ loading: false, success: false, error: false });

  const handlePhoneNumberSubmit = async () => {
    try {
      setStatus({ loading: true, success: false, error: false });

      const recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
        size: 'invisible',
      });

      const phoneNumber = "+90" + phone;

      const confirmationResult = await auth.signInWithPhoneNumber(phoneNumber, recaptchaVerifier);
      setVerificationId(confirmationResult.verificationId);

      setStatus({ loading: false, success: true, error: false });
      console.log('Doğrulama kodu gönderildi');
    } catch (error) {
      setStatus({ loading: false, success: false, error: true });
      console.log('Hata:', error);
    }
  };

  const handleCodeSubmit = async () => {
    try {
      setStatus({ loading: true, success: false, error: false });

      const credential = firebase.auth.PhoneAuthProvider.credential(verificationId, code);
      await auth.currentUser?.linkWithCredential(credential);

      setStatus({ loading: false, success: true, error: false });
      console.log('Telefon doğrulama bkodunu girin');
    } catch (error) {
      setStatus({ loading: false, success: false, error: true });
      console.log('Hata:', error);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Doğrulama</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
      <IonInput
       type="tel"
        placeholder="Telefon Numarası"
        value={phone}
        onIonChange={(event) => setPhone(event.detail.value!)}
       />

        <IonButton expand="block" onClick={handlePhoneNumberSubmit}>
          Doğrulama Kodu Gönder
        </IonButton>
        <IonInput
          placeholder="Doğrulama Kodunu Girin"
          value={code}
          onIonChange={(event) => setCode(event.detail.value!)}
        />
        <IonButton expand="block" onClick={handleCodeSubmit}>
          Kodu Doğrula
        </IonButton>
        
        {status.loading && <IonText>Loading...</IonText>}
        {status.success && <IonText color="success">Doğrulama kodunu giriniz.</IonText>}
        {status.error && <IonText color="danger">Telefon doğrulama hatası</IonText>}
        <div id="recaptcha-container"></div>
      </IonContent>
    </IonPage>
  );
};

export default Dogrulama;
