import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonInput, IonItem, IonToast, IonList, IonLabel, IonText, IonSpinner } from '@ionic/react';
import React, { useState } from 'react';
import './Tab1.css';
import './uyeol.css';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import { Redirect, useHistory } from 'react-router';
import { useAuth } from '../auth';

const UyeOl: React.FC = () => {
  const { loggedIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('5392255175');
  console.log(phoneNumber)
  const [status, setStatus] = useState({ loading: false, success: false, error: false });
  const history = useHistory();

  const handleUyeOl = async () => {
    if (!email || !password || !name || !phoneNumber) {
      setStatus({ loading: false, success: false, error: true });
      return;
    }

    try {
      setStatus({ loading: true, success: false, error: false });
      const credential = await firebase.auth().createUserWithEmailAndPassword(email, password);
      const user = credential.user;

      // Update user profile with name
      await user?.updateProfile({ displayName: name });

      // Save additional user data to Firestore or your preferred database
      await firebase.firestore().collection('users').doc(user?.uid).set({
        name,
        email,
        phoneNumber
      });

      console.log('Kullanıcı kaydedildi:', user);

      // Show success message
      setStatus({ loading: false, success: true, error: false });

      // Doğrulama sayfasına yönlendirme
      history.push('/tab2');
    } catch (error) {
      setStatus({ loading: false, success: false, error: true });
      console.log('Hata:', error);
    }
  };

  if (loggedIn) {
    return <Redirect to="/my/entries" />;
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Üye Ol</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonList className="ion-padding">
          <IonItem>
            <IonLabel position="stacked">Ad Soyad</IonLabel>
            <IonInput
              type="text"
              value={name}
              onIonChange={(event) => setName(event.detail.value!)}
            />
          </IonItem>
          <IonItem>
            <IonLabel position="stacked">E-posta</IonLabel>
            <IonInput
              type="email"
              value={email}
              onIonChange={(event) => setEmail(event.detail.value!)}
            />
          </IonItem>
          <IonItem>
            <IonLabel position="stacked">Şifre</IonLabel>
            <IonInput
              type="password"
              value={password}
              onIonChange={(event) => setPassword(event.detail.value!)}
            />
          </IonItem>
          <IonItem>
            <IonLabel position="stacked">Telefon Numarası</IonLabel>
            <IonInput
              type="tel"
              value={phoneNumber}
              onIonChange={(event) => setPhoneNumber(event.detail.value!)}
            />
          </IonItem>
        </IonList>
        {status.error && (
          <IonText color="danger">Lütfen geçerli bir e-posta, şifre, ad soyad ve telefon numarası girin.</IonText>
        )}
        {status.success && (
          <IonText color="success">Başarılı bir şekilde üye oldunuz.</IonText>
        )}
        <IonButton expand="block" onClick={handleUyeOl} disabled={status.loading}>
          Üye Ol
        </IonButton>
        {status.loading && <IonSpinner />}
      </IonContent>
    </IonPage>
  );
};

export default UyeOl;
