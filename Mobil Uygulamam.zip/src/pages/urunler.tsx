  import React, { useEffect, useState } from 'react';
  import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
  import firebase from "firebase/compat/app";
  import "firebase/compat/firestore";
  import { Product, Users } from './types';
  import './urunler.css'; // CSS dosyasını içe aktarın
  import { Link } from 'react-router-dom';


  const Urunler: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [userNames, setUserNames] = useState<{ [key: string]: string }>({});
    const [users, setUsers] = useState<Users[]>([]);

    useEffect(() => {
      const fetchProducts = async () => {
        try {
          const db = firebase.firestore();
          const snapshot = await db.collection("products").get();
          const fetchedProducts = snapshot.docs.map((doc) => doc.data() as Product);
          setProducts(fetchedProducts);
        } catch (error) {
          console.error("Veri çekme hatası:", error);
        }
      };

      const fetchUsers = async () => {
        try {
          const db = firebase.firestore();
          const snapshot = await db.collection("users").get();
          const fetchedUsers = snapshot.docs.map((doc) => doc.data() as Users);
          setUsers(fetchedUsers);
        
        } catch (error) {
          console.error("Veri çekme hatası:", error);
        }
      };

     

      const fetchUserNames = async (users: Users[]): Promise<{ [key: string]: string }> => {
        try {
          const userNames: { [key: string]: string } = {};
          await Promise.all(
            users.map(async (user) => { 
              if (!userNames[user.id]) {
                const userName = await fetchUserNames(user.id);
                userNames[user.id] = userName;
              }
            })
          );
          return userNames; // Kullanıcı adlarını içeren nesneyi döndür
        } catch (error) {
          console.error("Kullanıcı adlarını alma hatası:", error);
          return {}; // Hata durumunda boş bir nesne döndürdük
        }
      };
      

      fetchProducts();
      fetchUsers();
      fetchUserNames(users); // users değiştiğinde fetchUserNames'i tekrar çalıştırmak için
    }, [users]);

    return (
      <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Ürünler</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          {products.length > 0 ? (
            products.map((product, index) => (
              <Link to={`/products/${product.id}`} key={index}>
                <div className="urun-card">
                  <h3 className="product-title">{product.name}</h3>
                  <img src={product.image} alt="Ürün" />
                <p className="product-desc">{product.description}</p>
                <p className="product-price">Ürün Fiyatı: <span className="product-price-small">{product.price}</span></p>
              -
                </div>
              </Link>
            ))
          ) : (
            <p>Henüz ürün bulunmamaktadır.</p>
          )}
       
        </IonContent>
      </IonPage>
    );
  };

  export default Urunler;
