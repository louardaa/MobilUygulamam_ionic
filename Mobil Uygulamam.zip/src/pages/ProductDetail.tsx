import React, { useEffect, useState } from 'react';
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonSelect,
  IonSelectOption,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
} from '@ionic/react';
import { useParams } from 'react-router-dom';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import './ProductDetail.css';
import { Product, ProductVariant } from './types';
import { useHistory } from 'react-router-dom';


interface ProductVariant {
  id: string;
  color: string;
  size: string;
  price: number;
}

interface SepetItem {
  product: Product;
  variant: ProductVariant; // Ensure it has the correct properties (id, color, size, price)
  quantity: number;
}


const ProductDetail: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [variants, setVariants] = useState<ProductVariant[]>([]);
  const availableColors = ['Kırmızı', 'Mavi', 'Yeşil', 'Sarı', 'Siyah'];
  const availableSizes = ['S', 'M', 'L', 'XL', 'XXL'];
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [SepetItems, setSepetItems] = useState<SepetItem[]>([]);
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [purchaseSuccess, setPurchaseSuccess] = useState<boolean>(false);

  useEffect(() => {
    const db = firebase.firestore();
    const fetchProduct = async () => {
      try {
        const productDoc = await db.collection('products').doc(productId).get();
        const fetchedProduct = productDoc.data() as Product;
        setProduct(fetchedProduct);
      } catch (error) {
        console.error('Ürün verisini çekme hatası:', error);
      }
    };
    fetchProduct();
  }, [productId]);

  useEffect(() => {
    const db = firebase.firestore();
    const fetchVariants = async () => {
      try {
        const snapshot = await db
          .collection('productVariants')
          .where('productId', '==', productId)
          .get();
        const fetchedVariants = snapshot.docs.map(
          (doc) => doc.data() as ProductVariant
        );
        setVariants(fetchedVariants);
      } catch (error) {
        console.error('Seçenekleri çekme hatası:', error);
      }
    };
    fetchVariants();
  }, [productId]);

  const addToSepet = (
    product: Product,
    color: string,
    size: string,
    quantity: number
  ) => {
    const itemIndex = SepetItems.findIndex(
      (item) =>
        item.product.id === product.id &&
        item.variant.color === color &&
        item.variant.size === size
    );

    if (itemIndex !== -1) {
      const updatedSepetItems = [...SepetItems];
      updatedSepetItems[itemIndex].quantity += quantity;
      setSepetItems(updatedSepetItems);
    } else {
      setSepetItems((prevSepetItems) => [
        ...prevSepetItems,
        { product, variant: { color, size }, quantity },
      ]);
    }

    setPurchaseSuccess(true); // Show the purchase success message
  };
  
  

  const removeFromSepet = (productId: string, color: string, size: string) => {
    const updatedSepetItems = SepetItems.filter(
      (item) =>
        item.product.id !== productId ||
        item.variant.color !== color ||
        item.variant.size !== size
    );
    setSepetItems(updatedSepetItems);
  };

  const calculateTotalPrice = () => {
    let total = 0;
    SepetItems.forEach((item) => {
      total += item.product.price * item.quantity;
    });
    setTotalPrice(total);
  };

  const clearSepet = () => {
    setSepetItems([]);
    setTotalPrice(0);
  };

  const handleBuy = async () => {
    if (selectedColor && selectedSize) {
      console.log('Satın alma işlemi yapılıyor...');
      console.log('Seçilen Renk:', selectedColor);
      console.log('Seçilen Beden:', selectedSize);
      console.log('Adet:', quantity);

      addToSepet(product!, selectedColor!, selectedSize!, quantity);
      setPurchaseSuccess(true); // Set the purchase success message to true

      // Ürünü Firebase'e kaydet
      handleSaveProduct(product!.name, product!.price, selectedColor!, selectedSize!);

      // Siparişi Firebase'e kaydet
      await handleSaveOrder(product!.name, product!.price, selectedColor!, selectedSize!, quantity);

      history.push('/sepet', { SepetItems });
    }
  };
  const handleSaveProduct = async (name: string, price: number, color: string, size: string) => {
    try {
      const db = firebase.firestore();
      const productId = generateProductId(); // Özel ID oluştur
      await db.collection('products').doc(productId).set({
        id: productId,
        name,
        price,
        color,
        size,
      });
      console.log('Ürün başarıyla kaydedildi.');
    } catch (error) {
      console.error('Ürün kaydetme hatası:', error);
    }
  };
  const handleSaveOrder = async (
    productName: string,
    productPrice: number,
    color: string,
    size: string,
    quantity: number
  ) => {
    try {
      const db = firebase.firestore();
      const orderId = generateOrderId(); // Özel sipariş ID oluştur
      await db.collection('siparis').doc(orderId).set({
        orderId,
        productName,
        productPrice,
        color,
        size,
        quantity,
        orderDate: firebase.firestore.Timestamp.fromDate(new Date()), // Sipariş tarihini ekleyin
      });
      console.log('Sipariş başarıyla kaydedildi.');
    } catch (error) {
      console.error('Sipariş kaydetme hatası:', error);
    }
  };

  const generateOrderId = () => {
    // Daha sofistike bir özel ID üretme yöntemi kullanılabilir, ancak burada basit bir şekilde Math.random() kullanalım.
    return Math.random().toString(36).substr(2, 9);
  };

  const renderSepetItems = () => {
    if (SepetItems.length === 0) {
      return <p>Ürün bulunmamaktadır.</p>;
    }

    // Calculate total price for each item and update SepetItemsWithTotal
    const SepetItemsWithTotal = SepetItems.map((item) => ({
      ...item,
      total: item.product.price * item.quantity,
    }));

    // Calculate the total amount for all items in the Sepet
    const totalAmount = SepetItemsWithTotal.reduce(
      (total, item) => total + item.total,
      0
    );

    return (
      <>
        <IonList lines="full">
          {SepetItemsWithTotal.map((item) => (
            <IonItem key={`${item.product.id}-${item.variant.color}-${item.variant.size}`}>
              <IonLabel>
                <h2>{item.product.name}</h2>
                <p>Renk: {item.variant.color}</p>
                <p>Beden: {item.variant.size}</p>
                <p>Fiyat: {item.product.price} TL</p>
                <p>Adet: {item.quantity}</p>
                <p>Toplam: {item.total} TL</p>
              </IonLabel>
              <IonButton color="danger" onClick={() => removeFromSepet(item.product.id, item.variant.color, item.variant.size)}>
                Kaldır
              </IonButton>
            </IonItem>
          ))}
        </IonList>
        <div className="total-price">Toplam Fiyat: {totalAmount} TL</div>
        <IonButton color="warning" expand="full" onClick={clearSepet}>
          Sepeti Temizle
        </IonButton>
        <IonButton color="success" expand="full" onClick={checkout}>
          Sepete  Ekle
          
        </IonButton>
           {/* Display the success message */}
           {purchaseSuccess && <p>Ürün başarıyla sepete eklendi.</p>}
           
          
        
    
      </>
    );
  };

  const checkout = () => {
    console.log('Ödeme işlemi başarıyla gerçekleştirildi!');
    console.log('Sepet içeriği:', SepetItems);
    clearSepet();
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Ürün Detay</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {product ? (
          <div className="urun-detail">
            <h3 className="product-title">{product.name}</h3>
            <img src={product.image} alt="Ürün" />
            <p className="product-desc">Açıklama: {product.description}</p>
            <p className="product-price">Fiyat: {product.price}</p>

            <div className="product-option">
              <h4>Renk Seçenekleri:</h4>
              {selectedSize === null && (
                <p className="error-message">Lütfen bir renk seçiniz.</p>
              )}
              <IonSelect
                value={selectedColor}
                placeholder="Renk Seç"
                onIonChange={(e) => setSelectedColor(e.detail.value)}
              >
                {availableColors.map((color) => (
                  <IonSelectOption key={color} value={color}>
                    {color}
                  </IonSelectOption>
                ))}
              </IonSelect>
            </div>

            <div className="product-option">
              <h4>Beden Seçenekleri:</h4>
              <IonSelect
                value={selectedSize}
                placeholder="Beden Seç"
                onIonChange={(e) => setSelectedSize(e.detail.value)}
              >
                {availableSizes.map((size) => (
                  <IonSelectOption key={size} value={size}>
                    {size}
                  </IonSelectOption>
                ))}
              </IonSelect>
              {selectedSize === null && (
                <p className="error-message">Lütfen bir beden seçiniz.</p>
              )}
            </div>

            <div className="product-option">
              <IonLabel>Adet Seçin:</IonLabel>
              <IonInput
                type="number"
                value={quantity}
                onIonChange={(e) =>
                  setQuantity(e.detail.value ? parseInt(e.detail.value, 10) : 1)
                }
              />
            </div>

            <IonButton
              expand="full"
              color="primary"
              onClick={handleBuy}
              disabled={!selectedColor || !selectedSize}
            >
              Satın Al
            </IonButton>

            {/* Display the success message */}

          </div>
        ) : (
          <p>Henüz ürün bulunmamaktadır.</p>
        )}
        {renderSepetItems()}
      </IonContent>
    </IonPage>
  );
};

export default ProductDetail;
function handleSaveOrder(name: string, price: string, arg2: string, arg3: string, quantity: number) {
  throw new Error('Function not implemented.');
}

