import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonInput, IonButton, IonToast } from '@ionic/react';
import { useEffect, useState } from 'react';
import { auth } from '../firebase';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { useHistory } from 'react-router';



const Profil: React.FC = () => {
    const firestore = firebase.firestore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const history = useHistory();
  const user = auth.currentUser;
  const [showSuccessToast, setShowSuccessToast] = useState(false); // Boolean state for showing the toast

//email 
  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      setName(user.displayName || '');
      setEmail(user.email || '');
      // Telefon numarasını Firestore'dan alabilirsiniz
      firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .get()
        .then((doc) => {
        console.log('Profil güncellendi');
          if (doc.exists) {
            const userData = doc.data();
            if (userData) {
              setEmail(userData.email || '');
              console.log(userData.email)
            }
          }
        })
        .catch((error) => {
          console.log('Firestore Hatası:', error);
        });
    }
  }, []);

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      setName(user.displayName || '');
      setEmail(user.email || '');
      // Telefon numarasını Firestore'dan alabilirsiniz
      firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .get()
        .then((doc) => {
          if (doc.exists) {
            const userData = doc.data();
            if (userData) {
             setName(userData.name || '');
             console.log(userData.name)
            }
          }
        })
        .catch((error) => {
          console.log('Firestore Hatası:', error);
        });
    }
  }, []);

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      setName(user.displayName || '');
      setEmail(user.email || '');
      // Telefon numarasını Firestore'dan alabilirsiniz
      firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .get()
        .then((doc) => {
          if (doc.exists) {
            const userData = doc.data();
            if (userData) {
              setPhone(userData.phone || '');
              console.log(userData.phoneNumber)
            }
          }
         
        })
        .catch((error) => {
          console.log('Firestore Hatası:', error);
        });
    }
  }, []);

  const handleUpdateProfile = () => {
    const user = auth.currentUser;
    if (user) {
      // Kullanıcının adını güncelle
      user.updateProfile({displayName:name})
        .then(() => {
          console.log('Kullanıcı adı güncellendi:', name);
        })
        .catch((error) => {
          console.log('Kullanıcı adı güncelleme hatası:', error);
        });

      // Kullanıcının e-posta adresini güncelle
      user.updateEmail(email)
        .then(() => {
          console.log('E-posta adresi güncellendi:', email);
        })
        .catch((error) => {
          console.log('E-posta adresi güncelleme hatası:', error);
        });




        firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .set({ name: name }, { merge: true })
        .then(() => {
          console.log('İsim güncellendi:', name);
        })
        .catch((error) => {
          console.log('Firestore name güncelleme hatası:', error);
        });

        firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .set({ email: email }, { merge: true })
        .then(() => {
          console.log('Email güncellendi:', email);
        })
        .catch((error) => {
          console.log('Firestore email güncelleme hatası:', error);
        });

      // Kullanıcının telefon numarasını Firestore'da güncelle
      firebase
        .firestore()
        .collection('users')
        .doc(user.uid)
        .set({ phone: phone }, { merge: true })
        .then(() => {
          console.log('Telefon numarası güncellendi:', phone);
        })
        .catch((error) => {
          console.log('Firestore Telefon güncelleme hatası:', error);
        });

      history.push('/profil'); // Ana sayfaya yönlendirme
    }
  };
  
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Profil Düzenle</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonInput placeholder="İsminiz" value={name} onIonChange={(event) => setName(event.detail.value!)} />
        <IonInput type="email" placeholder="E-posta Adresiniz" value={email} onIonChange={(event) => setEmail(event.detail.value!)} />
        <IonInput placeholder="Telefon Numaranız" value={phone} onIonChange={(event) => setPhone(event.detail.value!)} />
        <IonButton expand="block" onClick={handleUpdateProfile}>
          Profili Güncelle
        </IonButton>
      </IonContent>
      <IonToast
        isOpen={showSuccessToast}
        message="Profiliniz başarıyla düzenlendi."
        duration={2000} // 2 saniye sonra otomatik kapanır
        onDidDismiss={() => setShowSuccessToast(false)}
      />
    </IonPage>
  );
};

export default Profil;
