import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonInput,
  IonItem,
  IonToast,
  IonButtons,
  IonList,
  IonLabel,
  IonText,
  IonSpinner,
} from '@ionic/react';
import React, { useState } from 'react';
import './Login.css';
import { useAuth } from '../auth';
import { auth } from '../firebase';
import { Redirect } from 'react-router';


const Login: React.FC = () => {
  const { loggedIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState({ loading: false, error: false });

  const handleLogin = async () => {
    try {
      setStatus({ loading: true, error: false });
      const credential = await auth.signInWithEmailAndPassword(email, password);
      console.log('credential:', credential);
    } catch (error) {
      setStatus({ loading: false, error: true });
      console.log('error:', error);
    }
  };

  if (loggedIn) {
    return <Redirect to="/my/entries" />;
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Giriş</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
      <div className="login-container">
          <IonList className="ion-padding">
            <IonItem>
              <IonLabel position="stacked">Email</IonLabel>
              <IonInput
                className="email-input"
                type="email"
                value={email}
                onIonChange={(event) => setEmail(event.detail.value!)}
              />
          </IonItem>
          <IonItem>
            <IonLabel position="stacked">Password</IonLabel>
            <IonInput
              className="password-input"
              type="password"
              value={password}
              onIonChange={(event) => setPassword(event.detail.value!)}
            />
          </IonItem>
        </IonList>
        {status.error && (
          <IonText className="error-message" color="danger">Kullanıcı Adı veya Şifre Hatalı</IonText>
        )}
        <IonButton className="login-button" expand="block" onClick={handleLogin} routerLink="/tab1">
          Login
        </IonButton>
        {status.loading && <IonSpinner />}
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Login;
