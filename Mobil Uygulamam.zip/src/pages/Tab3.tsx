import { IonApp, IonContent, IonHeader, IonInput, IonPage, IonTitle, IonToolbar, IonButton } from '@ionic/react';
import { useState } from 'react';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { CameraResultType, CameraSource } from '@capacitor/camera';
import { Camera } from '@capacitor/camera';
import { v4 as uuidv4 } from 'uuid';
import { useAuth } from '../hooks/useAuth';



const firebaseConfig = {
  apiKey: "AIzaSyCiSFl2YdFqEQlmhpW6_LbIVYuvCLLVZmM",
  authDomain: "mobiluygulamam-d2a6d.firebaseapp.com",
  projectId: "mobiluygulamam-d2a6d",
  storageBucket: "mobiluygulamam-d2a6d.appspot.com",
  messagingSenderId: "293918081654",
  appId: "1:293918081654:web:364512bb8f581b7cfc9557",
  measurementId: "G-Z775T8LZ7R"
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const firestore = firebase.firestore();

const Tab3: React.FC = () => {
  const { user } = useAuth();
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productImage, setProductImage] = useState('');

  const handleProductSubmit = async () => {
    if (!user) {
      console.error("No user found."); // Handle the case where the user is not logged in
      return;
    }

    const product = {
      id: uuidv4(),
      name: productName,
      description: productDescription,
      price: productPrice,
      image: productImage,
      addedBy: user.uid, 
    };

    try {
      await firestore.collection('products').doc(product.id).set(product); // Save the product with the generated ID
      console.log('Ürün başarıyla kaydedildi');
      // Use an appropriate method to pass the product to the Tab2 component
    } catch (error) {
      console.error('Ürün kaydetme hatası:', error);
    }
  };

  const handleImageUpload = async () => {
    try {
      const photo = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Prompt,
      });

      const productImage = 'data:image/jpeg;base64,' + photo.base64String;
      setProductImage(productImage);
    } catch (error) {
      console.log('Hata:', error);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Ürün Ekle</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonInput
          placeholder="Ürün Adı"
          value={productName}
          onIonChange={(event) => setProductName(event.detail.value!)}
        />
        <IonInput
          placeholder="Ürün Açıklaması"
          value={productDescription}
          onIonChange={(event) => setProductDescription(event.detail.value!)}
        />
        <IonInput
          placeholder="Ürün Fiyatı"
          value={productPrice}
          onIonChange={(event) => setProductPrice(event.detail.value!)}
        />
        <IonButton expand="block" onClick={handleImageUpload}>
          Resim Seç
        </IonButton>
        {productImage && (
          <img src={productImage} alt="Ürün Resmi" style={{ width: '100%', marginBottom: '10px' }} />
        )}
        <IonButton expand="block" onClick={handleProductSubmit}>
          Ürünü Ekle
        </IonButton>
      </IonContent>
    </IonPage>
  );
};



// Other declarations (constants, types, etc.)
export const someConstant = 'Some value';
export type SomeType = { /* ... */ };

export default Tab3;
