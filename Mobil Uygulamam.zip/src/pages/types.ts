

export interface Product {
    [x: string]: string;
    name: string;
    description: string;
    price: string;
    image:string;
  }
  
export interface Users {
  id: any;
  addedBy: any;
  email:string;
  name: string;
  phone: string;
  phoneNumber : string
}
export interface ProductDetails {
  addedBy: string;
  description: string;
  id:string;
  image:string;
  name:string;
  price:string;
}
// types.ts
export interface Product {
  id: string;
  name: string;
  description: string;

  image: string;
  addedBy: string; // Bu alan, ürünü ekleyen kullanıcının ID'sini içerecek
}

export interface Users {

  name: string;
  email: string;
  phone: string;
  phoneNumber: string;
  // Diğer kullanıcı bilgilerini buraya ekleyebilirsiniz
}
export interface ProductOption {
  id: string;
  name: string;
}

export interface ProductVariant {
  id: string;
  color: string;
  size: string;
  price: number;
}
export interface Siparis {
  [x: string]: any;
  id: any;
  price: ReactNode;
  color : string;
  orderDate: string;
  orderId: string;
  productName : string;
  productPrice : string;
  quantity : string;
  size : string
}