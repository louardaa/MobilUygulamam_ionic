import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonInput,
  IonItem,
  IonToast,
  IonButtons,
  IonList,
  IonLabel,
  IonText,
  IonSpinner,
} from '@ionic/react';
import React, { useState } from 'react';
import './Tab1.css';

import { useAuth } from '../auth';
import { auth } from '../firebase';
import { Redirect, useHistory } from 'react-router';


const Tab1: React.FC = () => {
  const { loggedIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState({ loading: false, error: false });
  const history = useHistory();

  const handleLogin = async () => {
    try {
      setStatus({ loading: true, error: false });
      const credential = await auth.signInWithEmailAndPassword(email, password);
      console.log('credential:', credential);
      history.push('/tab2'); // Yönlendirme yapılıyor
    } catch (error) {
      setStatus({ loading: false, error: true });
      console.log('error:', error);
    }
  };

  const handleUyeOl = () => {
    history.push('/UyeOl'); // Yönlendirme yapılıyor
  };

  if (loggedIn) {
    return <Redirect to="/my/entries" />;
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Giriş</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
      <div className="login-container">
        <IonList className="ion-padding">
          <IonItem>
            <IonLabel position="stacked">Mail</IonLabel>
            <IonInput
              type="email"
              value={email}
              onIonChange={(event) => setEmail(event.detail.value!)}
            />
          </IonItem>
          <IonItem>
            <IonLabel position="stacked">Şifre</IonLabel>
            <IonInput
              type="password"
              value={password}
              onIonChange={(event) => setPassword(event.detail.value!)}
            />
          </IonItem>
        </IonList>
        {status.error && (
          <IonText color="danger">Kullanıcı Adı veya Şifre Hatalı</IonText>
        )}
       <IonButton className="login-button" onClick={handleLogin}>
          Giriş Yap
        </IonButton>
        <IonButton className="login-button" onClick={handleUyeOl}>
          Üye Ol
        </IonButton>
        {status.loading && <IonSpinner />}
        <div className="forgot-password-container">
            <a className="forgot-password" href="sifremisifirla">
              Şifremi Unuttum
            </a>
          </div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Tab1;
