import { Redirect, Route } from 'react-router-dom';
import {
  IonApp,
  IonIcon,
  IonLabel,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  setupIonicReact
} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { ellipse, square } from 'ionicons/icons';
import Login from './pages/Login';
import Tab1 from './pages/Tab1';
import Tab2 from './pages/Tab2';
import Tab3 from './pages/Tab3';



/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';
import { auth } from './firebase';

/* Theme variables */
import './theme/variables.css';
import React,{ useEffect, useState } from 'react';
import UyeOl from './pages/uyeol';
import Dogrulama from './pages/dogrulama';
import Urunler from './pages/urunler';
import Profil from './pages/profil';
import SifreMiSifirla from './pages/sifremisifirla';
import ProductDetail from './pages/ProductDetail';
import Sepet from './pages/sepet';





setupIonicReact();

const App: React.FC = () => {

  const [loggedIn, setLoggedIn] = useState(false);
  
  useEffect(() => {
    auth.onAuthStateChanged((user) => {
      setLoggedIn(Boolean(user));
    });
  }, []);

  console.log(`rendering App with loggedIn=${loggedIn}`);

  return (
    <IonApp>
      <IonReactRouter>
        <IonTabs>
          <IonRouterOutlet>

            

               <Route exact path="/products/:productId">
              <ProductDetail />
            </Route>

            <Route exact path="/Login">
              <Login />
            </Route>

            <Route exact path="/sepet">
              <Sepet SepetItems={[]}   />
            </Route>


            <Route exact path="/ProductDetail">
              <ProductDetail />
            </Route>

            <Route exact path="/profil">
              <Profil />
            </Route>

            <Route exact path="/dogrulama">
              <Dogrulama />
            </Route>
            <Route exact path="/UyeOl">
              <UyeOl />
            </Route>

            <Route exact path="/urunler">
              <Urunler />
            </Route>
            <Route exact path="/uyeol">
              <UyeOl />
            </Route>
            <Route exact path="/tab1">
              <Tab1 /> 
            </Route>
            <Route exact path="/tab2">
              <Tab2 />
            </Route>
            <Route path="/tab3">
              <Tab3 />
            </Route>
            <Route exact path="/">
              <Redirect to="/tab1" />
            </Route>
            <Route exact path="/sifremisifirla">
              <SifreMiSifirla />
            </Route>           
          </IonRouterOutlet>
          <IonTabBar slot="bottom">
            
            <IonTabButton tab="tab2" href="/tab2">
              <IonIcon aria-hidden="true" icon={ellipse} />
              <IonLabel>Anasayfa</IonLabel>
            </IonTabButton>
            <IonTabButton tab="tab3" href="/tab3">
              <IonIcon aria-hidden="true" icon={square} />
              <IonLabel>Ürün Ekle</IonLabel>
            </IonTabButton>
            <IonTabButton tab="tab4" href="/urunler">
              <IonIcon aria-hidden="true" icon={square} />
              <IonLabel>Ürünler</IonLabel>
            </IonTabButton>

          </IonTabBar>
        </IonTabs>
      </IonReactRouter>
    </IonApp>
  );
}

export default App;
